This zip folder contains software code  for  my Project on Log Analytics on Operations Management Suite as part of my Deep Azure training. 
The follow scripts are uploaded: 

************************************************************************************************************************************
Infracreate.py : A python script that created some of infrastructure (VMs) I used for the project. This needs Python 3.6
************************************************************************************************************************************

Linuxsvcmon.sh: It is a simple shell script that tells us about a simple way of monitoring  Linux Processes. I used it to see up monitoring for the project on one of the processes running on a Linux VM.  It needs an input file. 

sampledatafor_linuxsvcmon.rtf : Contains sample data for Linuxsvcmon.sh
Here is an example for how to executing the script:  ./ Linuxsvcmon.sh sampledatafor_linuxsvcmon.rtf

************************************************************************************************************************************

OMSconfig.ps1: This is a PowerShell script for creating and configuring a new OMS workspace. 
************************************************************************************************************************************

OMSaddresournce.ps1: This is a PowerShell script for add Windows VMs to a existing OMS workspace. It needs an input file.

sampledatafor_OMSaddresournce.csv: It contains sample data for OMSaddresournce.ps1

Here is an example for how to executing the script: .\OMSaddresournce.ps1 sampledatafor_OMSaddresournce.csv

************************************************************************************************************************************

winsvcprocmon.ps1: This is a PowerShell script that helps us to monitor windows processes and services.It needs an input file

sampledatafor_winsvcprocmon.csv: It contains sample data for winsvcprocmon.ps1

Here is an example for how to executing the script: .\winsvcprocmon.ps1 sampledatafor_winsvcprocmon.csv


