﻿#This script is for cretating a new OMS workspace and configuring it. The configuration steps are requirement dependent and we can edit those steps. We can delete some of commands if we don't need any monitoring. 
#This has to be executed in foreground. It will prompt for Azure credentials.

$subscriptionid=Read-Host 'Input the subscription ID:'

Login-AzureRmAccount -subscriptionid  $Subscriptionid     

$ResourceGroup = Read-Host -Prompt 'Input your resource group  name'

$WorkspaceName = Read-Host -Prompt 'Input your workspace  name'
$Location = "eastus" 

write-host  'Checking if resource group exists. If not will create the resource group'


# Create the resource group if needed
try {
    Get-AzureRmResourceGroup -Name $ResourceGroup -ErrorAction Stop
} catch {
    New-AzureRmResourceGroup -Name $ResourceGroup -Location $Location

}

write-host  'Creating the workspace'

# Create the workspace
New-AzureRmOperationalInsightsWorkspace -Location $Location -Name $WorkspaceName -Sku Standard -ResourceGroupName $ResourceGroup

write-host  'Setting up Windows Event Monitors'

# Windows Event Configuration 

New-AzureRmOperationalInsightsWindowsEventDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -EventLogName "Application" -CollectErrors -CollectWarnings -Name "Example Application Event Log"

New-AzureRmOperationalInsightsWindowsEventDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -EventLogName "System" -CollectErrors -CollectWarnings -Name "System Event Log"

write-host  'Setting up Windows Performance Monitors'

# Windows Performance Configuration

write-host  'Setting up Windows Performance Monitors'

New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Logical Disk" -InstanceName "*" -CounterName ("% Free Space") -IntervalSeconds 10 -Name " Windows Logical Disk Performance Counter-1"
New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Logical Disk" -InstanceName "*" -CounterName ("Avg. Disk sec/Read") -IntervalSeconds 10 -Name " Windows Logical Disk Performance Counter-2"
New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Logical Disk" -InstanceName "*" -CounterName ("Avg. Disk sec/Write") -IntervalSeconds 10 -Name " Windows Logical Disk Performance Counter-3"
New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Logical Disk" -InstanceName "*" -CounterName ("Current Disk Queue Length") -IntervalSeconds 10 -Name " Windows Logical Disk Performance Counter-4"

New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Memory" -InstanceName "*" -CounterName ("% Committed Bytes In Use") -IntervalSeconds 10 -Name " Windows Memory Performance Counter-1"
New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Memory" -InstanceName "*" -CounterName ("Available MBytes") -IntervalSeconds 10 -Name " Windows Performance Counter-2"



New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Network Adapter" -InstanceName "*" -CounterName ("Bytes Received/sec ") -IntervalSeconds 20 -Name "Windows Network Adapter Performance Counter-1"
New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Network Adapter" -InstanceName "*" -CounterName ("Available MBytes") -IntervalSeconds 20 -Name " Windows Network Adappter Performance Counter-2"


New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Network Interface" -InstanceName "*" -CounterName ("Bytes Total/sec") -IntervalSeconds 20 -Name "Windows Network Inteface Performance Counter-1"

New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Processor" -InstanceName "*" -CounterName ("% Processor Time") -IntervalSeconds 10 -Name "Windows Processor Performance Counter-1"

New-AzureRmOperationalInsightsWindowsPerformanceCounterDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "System" -InstanceName "*" -CounterName ("Processor Queue Length") -IntervalSeconds 10 -Name "Windows System Performance Counter-1"


# Setting Up Linux Performance Counters


write-host  'Setting up Linux Performance Monitors'

New-AzureRmOperationalInsightsLinuxPerformanceObjectDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Network" -InstanceName "*"  -CounterNames @("%Processor Time", "%Priveleged Time") -IntervalSeconds 20  -Name "Linux Processor  Performance Counters"

New-AzureRmOperationalInsightsLinuxPerformanceObjectDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Logical Disk" -InstanceName "*"  -CounterNames @("% Used Inodes", "Free Megabytes", "% Used Space", "Disk Transfers/sec", "Disk Reads/sec", "Disk Reads/sec", "Disk Writes/sec") -IntervalSeconds 10  -Name "Linux Disk Performance Counters "

New-AzureRmOperationalInsightsLinuxPerformanceObjectDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -ObjectName "Memory" -InstanceName "*"  -CounterNames @("Available Mbytes Memory", "%User Memory", "% Used Swap Space") -IntervalSeconds 10  -Name "Linux Memory Performance Counters"
Enable-AzureRmOperationalInsightsLinuxPerformanceCollection -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName


# Linux Syslog

write-host  'Setting up Linux Syslog Monitors'


New-AzureRmOperationalInsightsLinuxSyslogDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -Facility "syslog" -CollectEmergency -CollectAlert -CollectCritical -CollectError -CollectWarning -Name "Linux syslog collection"

New-AzureRmOperationalInsightsLinuxSyslogDataSource -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -Facility "kern" -CollectEmergency -CollectAlert -CollectCritical -CollectError -CollectWarning -Name "Linux Kernal collection"

Enable-AzureRmOperationalInsightsLinuxSyslogCollection -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName


# Enable IIS Log Collection using agent

write-host  'Setting up IIS Log collection'


Enable-AzureRmOperationalInsightsIISLogCollection -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName

#List enabled solutions

write-host 'List enabled solution' 
(Get-AzureRmOperationalInsightsIntelligencePacks -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName).Where({($_.enabled -eq $true)})

write-host 'This script allows you to additional set up following solutions:'
write-host 'Alert Monitoring' 
$userdec = read-host 'Do you want to enable the solution Alert Management ? Answer in Y or N only'

if ($userdec="Y") 
{  
  Set-AzureRmOperationalInsightsIntelligencePack -ResourceGroupName $ResourceGroup -WorkspaceName $WorkspaceName -IntelligencePackName 'AlertManagement' -Enabled $true
  }