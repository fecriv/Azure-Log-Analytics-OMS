﻿#This script is for add new Windows VMs (only Windows) to an existing OMS workspace. 
#We need to create a .csv data file with Windows VMName ,Resource group and Location as columns.
#This has to be executed in foreground. It will prompt for Azure credentials.


$subscriptionid=Read-Host 'Input the subscription ID:'

Login-AzureRmAccount -subscriptionid  $Subscriptionid 

$FILE = Read-Host  -Prompt 'Input the full path along with the file name with VM Name and Resource Group Information'
$omsId = Read-Host -Prompt 'Input your OMS Workspace ID'
$omsKey = Read-Host -Prompt 'Input your OMS Workspace Key'

Write-Host 'Script for Installing and Configuring the OMS Agent.'

Import-CSV $file | ForEach-Object { 

$vmName = $_.VMName
$resourceGroup = $_.ResourceGroup
$location = $_.Location

Write-Host "Installing and Configuring the OMS Agent for $vmName."

# Install and configure the OMS agent

try {

$PublicSettings = New-Object psobject | Add-Member -PassThru NoteProperty workspaceId $omsId | ConvertTo-Json
$protectedSettings = New-Object psobject | Add-Member -PassThru NoteProperty workspaceKey $omsKey | ConvertTo-Json

#$PublicSettings = @{"workspaceId" = $omsId}
#$protectedSettings = @{"workspaceKey" = $omsKey}

Set-AzureRmVMExtension -ExtensionName "OMS" -ResourceGroupName $resourceGroup -VMName $vmName `
  -Publisher "Microsoft.EnterpriseCloud.Monitoring" -ExtensionType "MicrosoftMonitoringAgent" `
  -TypeHandlerVersion 1.0 -SettingString $PublicSettings ` -ProtectedSettingString $protectedSettings -Location $location -ErrorAction Stop
write-host "Setup OMS for VM: $vmname in resource group: $resourceGroup successful" 
  } catch {

  write-host "Setup OMS for VM: $vmname in resource group: $resourceGroup failed" 
  }
  

}