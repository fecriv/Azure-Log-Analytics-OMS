# -*- coding: utf-8 -*-
"""
Created on Wed Jan 24 19:48:09 2018

@author: ek81mja
"""

from azure.common.credentials import ServicePrincipalCredentials
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.network import NetworkManagementClient


print("\n\nThis script will create 2 Windows 2012 R2 VMs and 2 Ubuntu VMs along with necessary infrastructure")
print("------------------------------------------------------\n\n")


SUBSCRIPTION_ID = input("Please enter the Subscription ID:\n")
print("------------------------------------------------------")
print("\n")
appid = input("Please enter your application id:\n")
print("------------------------------------------------------")
print("\n")
secretcode = input("Please enter the secret code:\n")
print("------------------------------------------------------")
print("\n")
tenantid = input("Please enter the AD tenant-id:\n")
print("------------------------------------------------------")
print("\n")
resourcegroup_name = input("Please enter the resource group name:\n")
print("------------------------------------------------------")
print("\n")
location = input("Please enter location for your resources:\n")
print("------------------------------------------------------")
print("\n")
VM_NAME1 = input("Please enter the name of 1st Windows 2012 R2 VM:\n")
print("------------------------------------------------------")
print("\n")
VM_NAME2 = input("Please enter the name of 2nd Windows 2012 R2 VM:\n")
print("------------------------------------------------------")
print("\n")
VM_NAME3 = input("Please enter the name of 1st Ubuntu VM:\n")
print("------------------------------------------------------")
print("\n")
VM_NAME4 = input("Please enter the name of 2nd Ubuntu VM:\n")
print("------------------------------------------------------")
print("\n")

MYAVSET_W = input


def create_vm_windows(network_client, compute_client,x):
     nic = network_client.network_interfaces.get(
     resourcegroup_name, 
     'rkNic0' + str(x)
     )
     
       
     VMBUFF = "VM_NAME"+str(x)
     VM_NAME=eval(VMBUFF)
     
     
     vm_parameters = {
        'location': location,
        'os_profile': {
            'computer_name': VM_NAME,
            'admin_username': 'azureuser',
            'admin_password': 'Azure12345678'
        },
        'hardware_profile': {
            'vm_size': 'Standard_DS1'
        },
        
        'storage_profile': {
            'image_reference': {
                'publisher': 'MicrosoftWindowsServer',
                'offer': 'WindowsServer',
                'sku': '2012-R2-Datacenter',
                'version': 'latest'
            }
        },        
            
        'osDisk': {
            'createOption': 'fromImage',
            'managedDisk': {
                            'storageAccountType': "Standard_LRS"
                           }
                  },
                
        'network_profile': {
            'network_interfaces': [{
                'id': nic.id
            }]
        },
         
       
               
      } 
                
            
     creation_result = compute_client.virtual_machines.create_or_update(
        resourcegroup_name, 
        VM_NAME, 
        vm_parameters
     )

     return creation_result.result()
 
def create_vm_linux (network_client,compute_client,x):
    nic = network_client.network_interfaces.get(
     resourcegroup_name, 
     'rkNic0' + str(x)
     )
    
    VMBUFF = "VM_NAME"+str(x)
    VM_NAME=eval(VMBUFF)
    
    vm_parameters = {
        'location': location,
        'os_profile': {
            'computer_name': VM_NAME,
            'admin_username': 'azureuser',
            'admin_password': 'Azure12345678'
        },
        'hardware_profile': {
            'vm_size': 'Standard_DS1'
        },
        
        'storage_profile': {
            'image_reference': {
                'publisher': 'Canonical',
                'offer': 'UbuntuServer',
                'sku': '16.04.0-LTS',
                'version': 'latest'
            }
        },        
            
        'osDisk': {
            'createOption': 'fromImage',
            'managedDisk': {
                            'storageAccountType': "Standard_LRS"
                           }
                  },
                
        'network_profile': {
            'network_interfaces': [{
                'id': nic.id
            }]
        },
      }  

    creation_result = compute_client.virtual_machines.create_or_update(
        resourcegroup_name, 
        VM_NAME, 
        vm_parameters
     )

    return creation_result.result()            
    
def create_nic(network_client,x):
    myNic = 'rkNic0' + str(x)   
    subnet_info = network_client.subnets.get(
        resourcegroup_name, 
        'rk_vnet', 
        'frontend'
    )
    publicIPAddress = network_client.public_ip_addresses.get(
        resourcegroup_name,
        'rkIPAddress0' + str(x)
    )
    nic_params = {
        'location': location,
        'ip_configurations': [{
            'name': 'rkIPConfig0'+ str(x),
            'public_ip_address': publicIPAddress,
            'subnet': {
                'id': subnet_info.id
            }
        }]
    }
    creation_result = network_client.network_interfaces.create_or_update(
        resourcegroup_name,
        myNic,
        nic_params
    )

    return creation_result.result()


def create_subnet_back(network_client):
    subnet_params = {
        'address_prefix': '10.0.1.0/24'
    }
    creation_result = network_client.subnets.create_or_update(
        resourcegroup_name,
        'rk_Vnet',
        'Backend',
        subnet_params
    )

    return creation_result.result()


def create_subnet_front(network_client):
    subnet_params = {
        'address_prefix': '10.0.0.0/24'
    }
    creation_result = network_client.subnets.create_or_update(
        resourcegroup_name,
        'rk_Vnet',
        'Frontend',
        subnet_params
    )

    return creation_result.result()

    
def create_vnet(network_client):
    vnet_params = {
        'location': location,
        'address_space': {
            'address_prefixes': ['10.0.0.0/16']
        }
    }
    creation_result = network_client.virtual_networks.create_or_update(
        resourcegroup_name,
        'rk_VNet',
        vnet_params
    )
    return creation_result.result()
    
    
def create_public_ip_address(network_client,x):
   
    myipaddress = 'rkIPAddress0' + str(x)
    public_ip_addess_params = {
        'location': location,
        'public_ip_allocation_method': 'Static'
    }
    creation_result = network_client.public_ip_addresses.create_or_update(
        resourcegroup_name,
        myipaddress,
        public_ip_addess_params
    )

    return creation_result.result()   


def create_resource_group(resource_group_client):
    resource_group_params = { 
     'location':location
     }
    
    resource_group_result = resource_group_client.resource_groups.create_or_update(
        resourcegroup_name, 
        resource_group_params
    )
    
    
    

def get_credentials():
    credentials = ServicePrincipalCredentials(
        client_id = appid,
        secret = secretcode,
        tenant = tenantid
        
    )

    return credentials

        
if __name__ == "__main__":
    
    
    credentials = get_credentials()

    resource_group_client = ResourceManagementClient(
    credentials, 
    SUBSCRIPTION_ID
)
    network_client = NetworkManagementClient(
    credentials, 
    SUBSCRIPTION_ID
)
    compute_client = ComputeManagementClient(
    credentials, 
    SUBSCRIPTION_ID
) 
    

    
    print("Creating resource group:"+resourcegroup_name+"............")
    create_resource_group(resource_group_client)
    input('Resource group created. Press enter to continue...')
    print(" ")
    
        
    print("Creating virtual network rk_Vnet............")
    creation_result = create_vnet(network_client)
    print("------------------------------------------------------")
    print(creation_result)
    input('Press enter to continue...')
    print(" ")
    
    for x in range(1,5):
     print("------------------------------------------------------")   
     print("Creating public IP configuration rkIPConfig0"+str(x))   
     creation_result = create_public_ip_address(network_client,x)
     print("------------------------------------------------------")
     print(creation_result)
    input('Press enter to continue...')
    print(" ")
    
    
    print("Creating subnet: Frontend............")
    creation_result = create_subnet_front(network_client)
    print("------------------------------------------------------")
    print(creation_result)
    input('Press enter to continue...')
    print(" ")
    
    print("Creating subnet: Backend............")
    creation_result = create_subnet_back(network_client)
    print("------------------------------------------------------")
    print(creation_result)
    input('Press enter to continue...')
    print(" ")
    
    for x in range(1,5):
     print("------------------------------------------------------")   
     print("Creating NIC rkNic0"+str(x))   
     creation_result = create_nic(network_client,x)
     print("------------------------------------------------------")
     print(creation_result)
    input('Press enter to continue...')
    print(" ")
    
    
    for x in range(1,3):  
     print("------------------------------------------------------")   
     print("Creating Windows VM")
     creation_result = create_vm_windows(network_client, compute_client,x)
     print("------------------------------------------------------")
     print(creation_result)
     print("------------------------------------------------------")
    input('Press enter to continue...')
    print(" ")
    
    for x in range(3,5):  
     print("------------------------------------------------------")   
     print("Creating Ubuntu VM")
     creation_result = create_vm_linux(network_client, compute_client,x)
     print("------------------------------------------------------")
     print(creation_result)
     print("------------------------------------------------------")
    input('Press enter to continue...')
    print(" ")
    
    print("Summary of the Results")
    print("------------------------------------------------------")
    print("Resource Group Name:"+resourcegroup_name)
    for x in range(1,5):
     VMBUFF = "VM_NAME"+str(x)
     VM_NAME=eval(VMBUFF)
     print("Name of VM#"+str(x)+" is:"+VM_NAME)
    print("------------------------------------------------------")       
    
    
    






    