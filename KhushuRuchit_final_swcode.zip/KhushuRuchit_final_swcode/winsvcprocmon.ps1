﻿# 1. This script is for Monitoring Pre-defined Services and Processes at OS level and in case any of the services/processes is down it will write an eror log to Application eveny log !
#2. For processes you may have to define the source using the command . For example if you want monitor a process "abcxyz" you need to issue the comamand: New-EventLog –LogName Application –Source “processname”. For example if you want to monitor if process iexplorer.exe is up the command would be New-EventLog –LogName Application –Source “iexplore”
#3. This script needs a .csv fie as argument . The .csv file will contain the data. It has to have two fields : 1. Name (name of the service/process to be monitored) 2. Type ( Either Service or Process)
#4. In order to execute it please run it as .\<scriptname>.ps1 <data.csv full path> . For example .\svcprocmon.ps1 C:\datapath\Data.csv

$file = $args[0];

if (!$file) {

write-host 'No data file found. Please give datafile when executing the script.Exiting'
exit

}

Import-CSV $file | ForEach-Object { 
         
$MYNAME = $_.Name
$TYPE = $_.Type




 if ($Type -eq 'Service') {

 
$ServiceDetails = Get-Service -Name $MYNAME
 if ($ServiceDetails.Status -ne "Running"){

Write-EventLog -LogName "Application" -Source $MYNAME -EventID 1 -EntryType Error -Message "$TYPE $MYNAME is down." -Category 1 -RawData 10,20
}
}


elseif ($TYPE -eq "Process") {


$ProcessDetails = Get-Process -Name $MYNAME -ErrorAction SilentlyContinue
if (!$ProcessDetails) {

Write-EventLog -LogName "Application" -Source $MYNAME -EventID 1 -EntryType Error -Message "$TYPE $MYNAME is down." -Category 1 -RawData 10,20
}
}

elseif ($TYPE -ne "Service" -and  $TYPE -ne "Process") {

Write-Host "Incorrect type found for $MYName type. Type should be Service or Process. Instead $Type found.Continuing nevertheless" -ErrorAction SilentlyContinue 

}

}
